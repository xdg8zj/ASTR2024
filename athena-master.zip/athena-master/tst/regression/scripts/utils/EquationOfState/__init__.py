brent_opt = dict(full_output=True, disp=True)
ode_opt = dict(mxstep=5000000, rtol=1e-15, atol=1e-13)
